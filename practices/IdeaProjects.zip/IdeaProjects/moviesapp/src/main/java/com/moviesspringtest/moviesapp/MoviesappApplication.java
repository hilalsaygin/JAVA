package com.moviesspringtest.moviesapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.GetMapping;
import org.springframework.boot.autoconfigure.RestController;


@SpringBootApplication
@RestController // states that this class s REST API controller
public class MoviesappApplication {

	public static void main(String[] args) {

		//run() method of SpringApplication class run the project on server
		//takes the project name as argument
		SpringApplication.run(MoviesappApplication.class, args);
	}
	//write endpoint for get
	//inside the brackets we can specify url adress of the page for the message to be displayed
	@GetMapping("/") // indicates that the method is get  endpoint
	public String api_front_root(){
		return "Movies to be listed\n";
	}
}
