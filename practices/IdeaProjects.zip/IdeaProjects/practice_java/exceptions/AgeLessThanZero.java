public class AgeLessThanZero extends Exception{
    public AgeLessThanZero(){}
    public AgeLessThanZero(String message){
        super(message);
    }
}