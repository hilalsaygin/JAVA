public class std_InOut_scanner {
}
