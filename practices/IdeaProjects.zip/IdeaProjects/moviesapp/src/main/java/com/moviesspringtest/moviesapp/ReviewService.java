package com.moviesspringtest.moviesapp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class ReviewService {
    @Autowired
    private ReviewRepository repository;

    //create MongoTemplate that is used to associate rview with movie
    @Autowired
    private MongoTemplate mongoTemplate;

    //takes review and movie imdbId as parameter
    public Review addReview(String reviewBody, String imdbId) {
        //create new review object
        // and insert the review into review collection by calling insert method of ReviewRepository class

        Review review =repository.insert(new Review(reviewBody)); ;
        //associate the created review with the Movie identified by its imdbId
        mongoTemplate.update(Movie.class)
                //matching() method to identitfy movie
                .matching(Criteria.where("imdbId").is(imdbId))
                //push() method to add the review list varable of the Movie object
                .apply(new Update().push("reviews").value(review))
                .first();

        return review;
    }
}