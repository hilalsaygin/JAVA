import java.util.*;
import java.lang.*;
import java.util.regex.*;


public class hcrank_std_InOut {
public static void multiline_input(){
    Scanner input = new Scanner(System.in);
    List<String> tokens = new ArrayList<>();
    String line;
//read multiple line console input into arraylist
    while (input.hasNextLine()) {
        line=input.nextLine();
        if (line.isEmpty()) {
            break;
        }
        tokens.add(line);
    }
    for (String token : tokens) {
        System.out.print(token);
        System.out.print("\n");
    }
    input.close();

}
public static void if_else_statement(){
    Scanner scanner = new Scanner(System.in);
    int N;
    if(scanner.hasNextInt()){
        N = scanner.nextInt();
        if( N%2!=0){
            System.out.println(("Weird"));
        }
        else{
            if(N>=2 && N<=5){
                System.out.println(("Not Weird"));}
            else if(N>=6 && N<=20){
                System.out.println(("Weird"));}
            else if(N >20&& N<=100 ){
                System.out.println(("Not Weird"));}
        }
    }
    else{
        System.out.println(("Invalid Input"));}
    scanner.close();
}
public static void javaArrayList(){
    Scanner scanner =new Scanner(System.in);
    int N,d,q,x,y;
    ArrayList<ArrayList<Integer>> array = new ArrayList<ArrayList<Integer>>();

    if(scanner.hasNextInt()){
        N = scanner.nextInt();

        for (int i=0; i<N;i++){
            array.add(new ArrayList<Integer>());
            d= scanner.nextInt();
            System.out.println(d);
            for(int j=0; j <d; j++){
                if(scanner.hasNextInt()){
                    int k= scanner.nextInt();
                    array.get(i).add(j,k );
                }

            }
        }
        q= scanner.nextInt();
        for(int i=0;i<q;i++){
            x=scanner.nextInt();
            y=scanner.nextInt();
            System.out.println(array.get(x).get(y));


        }


        System.out.println(array);

    }


}
    public static void java_loppsII (){
        Scanner scanner = new Scanner(System.in);
        int a,q,b,n,expr=0;
        q = scanner.nextInt();
        for (int i = 0; i < q; i++) {
                a = scanner.nextInt();
                b = scanner.nextInt();
                n = scanner.nextInt();
                for (int j = 0; j < n; j++) {
                    expr += (Math.pow(2, j) * b);
                    System.out.print(a+expr);
                    System.out.print(" ");
                }
                System.out.print("\n");
                expr=0;
            }
            scanner.close();

    }
    public static void concatenate_strings(){
        Scanner scanner = new Scanner(System.in);
        String a= scanner.nextLine();
        String b= scanner.nextLine();
        int len_a=a.length();
        int len_b=b.length();
        System.out.println(len_a+len_b);

        int compare = a.compareTo(b);
        if(compare>0){
            System.out.println("Yes"); }
        else {
            System.out.println("No"); }

        String a_out = a.substring(0, 1).toUpperCase() + a.substring(1);
        String b_out = b.substring(0, 1).toUpperCase() + b.substring(1);
        System.out.println(a_out+" "+b_out);

    }
    public static void pattern_complie_regex(){
        Scanner in = new Scanner(System.in);
        int testCases = Integer.parseInt(in.nextLine());
        while(testCases>0 && in.hasNextLine()){
            String pattern = in.nextLine();
            try {
                Pattern.compile(pattern);
                System.out.println("Valid");
                testCases--;
            } catch (Exception PatternSyntaxException ) {
                System.out.println("Invalid");
            }

        }

    }

    public static void main(String[] args) {
       // multiline_input();
       // if_else_statement();
       // javaArrayList();
        //java_loppsII();
        concatenate_strings();
    }
}

