import java.io.*;
import java.util.*;

public class CustomException {
    public static void main(String[] args) throws AgeLessThanZero{
        Scanner scan = new Scanner(System.in);

        System.out.print("Enter your name:");
        String name=scan.nextLine();
        try{
            System.out.print("Enter your age:");
            int age=scan.nextInt();
            age_validation(age);

        }
        catch (InputMismatchException e){
            System.out.print("Non-integer input!!");
        }
    }
    public static void age_validation(int a) throws AgeLessThanZero{
        if (a<0)
            throw new AgeLessThanZero("Human age cannot be a negative value!!");
    }
}