#!/bin/python3

import math
import os
import random
import re
import sys


#
# Complete the 'countSignals' function below.
#
# The function is expected to return an INTEGER.
# The function accepts following parameters:
#  1. INTEGER_ARRAY frequencies
#  2. 2D_INTEGER_ARRAY filterRanges
#

def countSignals(frequencies, filterRanges):
    # Write your code here
    lower_bound=filterRanges[0][0]
    upper_bound=filterRanges[0][1]
    passed_sig=0
    #ran is a list for containing freq bounds 
    
    for ran in filterRanges:
        #lower bound comparison
        if ( ran[0] > lower_bound ):
            lower_bound=ran[0]
        if( ran[1] < upper_bound):
            upper_bound=ran[1]
    # now compare each given signals if they fit the overlapping bounds
    for f in frequencies:
        if ( f >= lower_bound and f <= upper_bound):
            passed_sig +=1
    return passed_sig
            
            
            
        
        
    
    
if __name__ == '__main__':
    fptr = open(os.environ['OUTPUT_PATH'], 'w')

    frequencies_count = int(input().strip())

    frequencies = []

    for _ in range(frequencies_count):
        frequencies_item = int(input().strip())
        frequencies.append(frequencies_item)

    filterRanges_rows = int(input().strip())
    filterRanges_columns = int(input().strip())

    filterRanges = []

    for _ in range(filterRanges_rows):
        filterRanges.append(list(map(int, input().rstrip().split())))

    result = countSignals(frequencies, filterRanges)

    fptr.write(str(result) + '\n')

    fptr.close()
