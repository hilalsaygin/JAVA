package com.moviesspringtest.moviesapp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/main/reviews")
public class ReviewController {
    //declare ReviewService object
    @Autowired
    private ReviewService service;

    @PostMapping() //annotate that method is mapped to post request handling
    //takes RequestBody as parameter and map it String,String key-value pair named payload
    public ResponseEntity<Review> createReview(@RequestBody Map<String, String> payload) {
        return new ResponseEntity<Review>(
                // call addReview() method of ReviewService object
                //call get mothod on payload Map object to retrieve reviewBody and imdbId seperately
                //then pass the reviewbody and imdbId as parameters to addReview() method
                service.addReview(
                        payload.get("reviewBody"), payload.get("imdbId")
                ), HttpStatus.OK);
    }
}