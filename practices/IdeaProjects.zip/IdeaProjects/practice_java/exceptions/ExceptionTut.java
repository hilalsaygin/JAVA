import java.io.*;
import java.util.*;
import java.text.*;

public class ExceptionTut{
public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        try {
            int a = sc.nextInt();
            int b = sc.nextInt();
            System.out.println(a / b);

        } 
        catch(Exception e) {
            System.out.println(e.getClass().getName().toString());
        }
        sc.close();
    }
}
