package com.moviesspringtest.moviesapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoviesappApplicationTests {

	@Test
	void contextLoads() {
	}

}
